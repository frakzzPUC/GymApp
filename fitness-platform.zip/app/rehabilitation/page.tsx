"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export default function RehabilitationPage() {
  const [selectedPain, setSelectedPain] = useState<string | null>(null)
  const router = useRouter()

  const painOptions = [
    { id: "lower-back", label: "Dor na lombar" },
    { id: "neck", label: "Dor no pescoço" },
    { id: "shoulder", label: "Dor nos ombros" },
    { id: "knee", label: "Dor nos joelhos" },
    { id: "hip", label: "Dor no quadril" },
    { id: "wrist", label: "Dor nos pulsos" },
  ]

  const handleSubmit = () => {
    if (selectedPain) {
      // Em uma aplicação real, você salvaria a escolha do usuário
      router.push("/dashboard?program=rehabilitation")
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <div className="mr-6 flex items-center space-x-2">
              <span className="font-bold text-xl">FitJourney</span>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-8">
        <div className="mx-auto max-w-2xl">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Programa de Reabilitação</CardTitle>
              <CardDescription>
                Selecione a área onde você sente dor para recebermos exercícios personalizados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup value={selectedPain || ""} onValueChange={setSelectedPain} className="space-y-3">
                {painOptions.map((option) => (
                  <div key={option.id} className="flex items-center space-x-2 rounded-md border p-3">
                    <RadioGroupItem value={option.id} id={option.id} />
                    <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
            <CardFooter>
              <Button
                onClick={handleSubmit}
                disabled={!selectedPain}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
              >
                Continuar
              </Button>
            </CardFooter>
          </Card>
        </div>
      </main>
    </div>
  )
}
